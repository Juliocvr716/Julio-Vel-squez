// se omitido los acentos en los comentarios por compatibilidad

$(document).ready(function () {

  //cargando los datos
  $.ajax({
    url: "info.json"
  }).done(function (resultado) {

    //llenando la variable
    eventos = resultado.eventos;

    //obteniendo el id del url
    var id = location.search.match(/id=(\d)*/)[1]

    evento = eventos.find(function (element) {
      return element.id == id
    })
    //llenando dinamicamente los eventos
    var html = `
                <div>
                <a href="detalle.html?id=${pasados[j].id}"><h2>${pasados[j].title}</h2></a>${evento.title}
                <p id=descripción>Descripción: ${evento.body}</p>
                <p id=fecha>${evento.fecha}</p>
                </div>
                `
    document.getElementById("evento").innerHTML = html
  });

});
